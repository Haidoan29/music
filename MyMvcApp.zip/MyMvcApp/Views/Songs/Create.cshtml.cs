using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyMvcApp.Views.Songs
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
