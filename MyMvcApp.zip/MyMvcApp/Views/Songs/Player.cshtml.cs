using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyMvcApp.Views.Songs
{
    public class PlayerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
